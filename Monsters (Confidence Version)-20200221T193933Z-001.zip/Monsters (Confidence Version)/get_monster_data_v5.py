from sqlalchemy import create_engine, MetaData, Table
import json
import csv
#import pandas as pd

db_url = "mysql://psiturk:ps!turk@localhost:3306/psiturk"
#db_url = "sqlite:///participants.db" #for retrieving data from your local sqlite db
table_name = 'monsters'
data_column_name = 'datastring'
# boilerplate sqlalchemy setup
engine = create_engine(db_url)
metadata = MetaData()
metadata.bind = engine
table = Table(table_name, metadata, autoload=True)
# make a query and loop through
s = table.select()
rows = s.execute()

subject_data_filename = "monsters_data.csv"
extra_data_filename = "monsters_extra_data.csv"

data_header = ["participant:assignmentId", "condition", "state", "trial", "blockTrial", "trialStartTime", "monster", "family", "predictiveValidity", "predictiveFeature", "preferredFood", "choice", "correct", "rt", "foodConfidenceRating", "featureConfidenceRating", "interestRating"]

#create header for post-task questionnaire data
#need to make sure the monster families match with what's in the task!
monsterFamilies = ["Bear", "Bunny", "GreenMonster", "Squid"]
extra_header = ["participant:assignmentId", "condition"]
for monster in monsterFamilies:
    extra_header.append("interested-" + monster)
    extra_header.append("complex-" + monster)
    extra_header.append("time-" + monster)
    extra_header.append("progress-" + monster)
    extra_header.append("rule-" + monster)
    extra_header.append("future-learn-0-" + monster)
    extra_header.append("future-learn-1-" + monster)

#then add all non-monster related questions
extra_header.extend(["age", "gender", "race", "ethnicity", "thoughts", "comments"])

code_version = 1.5

#stores data that will actually be reported
valid_data = []
#status codes of subjects who completed experiment
statuses = [3,4,5,7]
# if you have workers you wish to exclude, add them here
exclude = []
for row in rows:
    # only use subjects who completed experiment and aren't excluded, and also check code version
    if row['status'] in statuses and row['uniqueid'] not in exclude and float(row['codeversion']) >= code_version:
        valid_data.append(row[data_column_name], )

# Now we have all participant datastrings in a list.
# Let's make it a bit easier to work with:

# parse each participant's datastring as json object
all_data = [json.loads(part) for part in valid_data]

# and take the 'data' sub-object
#data = [part['data'] for part in all_data]
#conditions = [part['condition'] for part in all_data]

with open(subject_data_filename, "wb") as subj_file:

    sf = csv.writer(subj_file)
    sf.writerow(data_header)

    #for part in data:
    for part in all_data:
	data = part['data']
	part_condition = part['condition']

        for record in data:

            sf.writerow((
                record['uniqueid'],
		part_condition,
                record['trialdata'].get('state'),
                record['trialdata'].get('trial'),
                record['trialdata'].get('blockTrial'),
                record['trialdata'].get('trialStartTime'),
                record['trialdata'].get('monster'),
                record['trialdata'].get('family'),
                record['trialdata'].get('predictiveValidity'),
                record['trialdata'].get('predictiveFeature'),
                record['trialdata'].get('preferredFood'),
                record['trialdata'].get('choice'),
                record['trialdata'].get('correct'),
                record['trialdata'].get('rt'),
                record['trialdata'].get('foodConfidenceRating'),
                record['trialdata'].get('featureConfidenceRating'),
                record['trialdata'].get('interestRating')
                ))

with open(extra_data_filename, "wb") as extra_file:

    ef = csv.writer(extra_file)
    ef.writerow(extra_header)

    for part in all_data:
        response_data = [part['workerId'] + ":" + part['assignmentId']]
	response_data.append(part['condition'])
        responses = part['questiondata']

        #get responses for monster-related questions
        for monster in monsterFamilies:
            response_data.append(responses.get('interested-' + monster))
            response_data.append(responses.get('complex-' + monster))
            response_data.append(responses.get('time-' + monster))
            response_data.append(responses.get('progress-' + monster))
            response_data.append(responses.get('rule-' + monster))
            response_data.append(responses.get('future-learn-0-' + monster, -1)) #default to -1 when this question doesn't exist
            response_data.append(responses.get('future-learn-1-' + monster))

        #get responses for all other questions
        response_data.extend([responses.get('age'),
            responses.get('gender'),
            responses.get('race'),
            responses.get('ethnicity'),
            responses.get('thoughts'),
            responses.get('comments')])

        #change list to tuple
        response_data_tuple = tuple(response_data)

        #output demographics and subject post-task responses
        ef.writerow(response_data_tuple) 
